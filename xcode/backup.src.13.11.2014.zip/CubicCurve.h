//
//  CubicCurve.h
//  DrawingToolkit
//
//  Created by Engage on 29/10/2014.
//
//

#ifndef __DrawingToolkit__CubicCurve__
#define __DrawingToolkit__CubicCurve__

#include <stdio.h>
#include <math.h>

#include "QuadraticCurve.h"
#include "cinder/app/AppNative.h"

#define CAP_SEGMENT_WIDTH 1.0


#define MAX_LINE_WIDTH 5.0
#define MIN_LINE_WIDTH 0.25

using namespace ci;

class CubicCurve
{
public:
    
    CubicCurve();
     Vec2f	anchor1;
    Vec2f	anchor2;
    
    Vec2f	control1;
    Vec2f	control2;
    void draw(bool drawControlPoints, float lineWidth, bool isBegin, bool isEnd);
    
    void setVelocities(float v1,float v2);
private:
    void drawCubicFromCentreCurve(float lineWidthFront, float lineWidthBack);
    Vec2f cubicCalc(Vec2f p0, Vec2f p1, Vec2f p2, Vec2f p3,float t);
    void drawCap(Vec2f a0, Vec2f a1, Vec2f a2, Vec2f a3, float angleStart);
    void drawCurve(float lineWidthFront, float lineWidthBack, bool isBegin, bool isEnd);
    void drawCinder(float lineWidth);
    
    float vFront, vEnd;
};

#endif 
