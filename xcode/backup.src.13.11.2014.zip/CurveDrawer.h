#ifndef CURVELINEANGLE_H
#define CURVELINEANGLE_H

#include "vector"
#include "deque"
#include "cinder/app/AppNative.h"
#include "cinder/Rand.h"
#include "cinder/Utilities.h"
#include "cinder/gl/Texture.h"
#include "cinder/Text.h"
#include "cinder/Vector.h"
#include "cinder/Path2d.h"
#include "cinder/gl/gl.h"
#include "CinderOpenCV.h"
#include "KalmanFilter.h"
#include "QuadraticCurve.h"
#include "CubicCurve.h"
#include "TouchVec2f.h"


#define SMOOTHNESS		0.4f
#define RAPIDNESS		0.4f

#define ANGLE_THRESH 0.2f

#define MAX_LINE_WIDTH 50.0f
#define MIN_LINE_WIDTH 0.5f

#define LINE_SIZE_MULTIPLIER 25.0f

class CurveDrawer
{
public:
    CurveDrawer();

	
	void mouseDown(Vec2f pos,float kalmanSmoothness_,float kalmanRapidness_,float angleThresh_, float cubicNormalMultiplier_, float minDistance_,float sharpAngleThresh_);
	void mouseUp(MouseEvent event);
	void mouseDrag(Vec2f pos, float minDistance);
	void update();

	void clear();
	void draw();
    
    void toggleKalmanFilter();
    void toggleDrawPointsPreKalman();
    void toggleDrawPointsPostKalman();
    void toggleDrawPointsAngleFilter();
    void toggleShowAnglePoints();
    void toggleDrawQuadratics();
    void toggleDrawCubics();
    void toggleDrawQuadraticPoints();
    void toggleUseCubicNormalAdjuster();
    void toggleDrawCubicControlPoints();
    
    bool isUsingKalmanFilter();
    bool isDrawPointsPreKalman();
    bool isDrawPointsPostKalman();
    bool isDrawPointsWithAngleFiltering();
    bool isShowAngleFilterPoints();
    bool isDrawQuadratics();
    bool isDrawCubics();
    bool isDrawQuadraticPoints();
    bool isUsingCubicNormalAdjuster();
    bool isDrawCubicControlPoints();
    
    int getNumPreKalmanPoints();
    int getNumPostKalmanPoints();
    
    int getNumCubics();
    int getNumQuadratics();
    void updateParams(float kalmanSmoothness_,float kalmanRapidness_,float angleThresh_,float cubicNormalMultiplier_, float minDistance_,float sharpAngleThresh_);
private:
    void loadKalmanPoints();
    
    bool                            drawCubicControlPoints;
    bool                            useCubicNormalAdjustment;
    bool                            useKalmanFilter;
    bool                            drawPointsPreKalman;
    bool                            drawPointsPostKalman;
    bool                            drawPointsAngleFilterKalman;
    bool                            drawQuadratics;
    bool                            drawQuadraticPoints;
    bool                            drawCubics;
    bool                            showAngleFilteredLinePoints;
	float							smoothness;
	float							rapidness;
    float                           cubicNormalMultiplier;
    float                           sharpAngleThresh;
    float                           minDistance;
    
    std::deque<TouchVec2f>               pointsPreKalman;
    std::deque<TouchVec2f>               pointsPostKalman;
    std::vector<QuadraticCurve>     quadCurveLines;
    std::vector<CubicCurve>         cubicCurveLines;

    float                           lineWidth;
	KalmanFilter					kalmanFilter;

};

#endif




