//
//  QuadraticCurve.h
//  DrawingToolkit
//
//  Created by Engage on 29/10/2014.
//
//

#ifndef __DrawingToolkit__QuadraticCurve__
#define __DrawingToolkit__QuadraticCurve__

#include <stdio.h>

#include "cinder/app/AppNative.h"


using namespace ci;

class QuadraticCurve
{
public:
    
    QuadraticCurve(Vec2f p1_, Vec2f p2_, Vec2f p3_, float v1, float v2);
    void draw();
    
    void calcMidSectionFromPoints();
    void calcBeginningSectionFromPoints();
    void calcEndSectionFromPoints();
    
    Vec2f p1,p2,p3;
    float vFront, vEnd;
private:
    Vec2f getMidPoint(Vec2f pA, Vec2f pB);

};
#endif /* defined(__DrawingToolkit__QuadraticCurve__) */
