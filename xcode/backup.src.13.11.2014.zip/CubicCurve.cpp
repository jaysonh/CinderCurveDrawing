//
//  CubicCurve.cpp
//  DrawingToolkit
//
//  Created by Engage on 29/10/2014.
//
//

#include "CubicCurve.h"

CubicCurve::CubicCurve()
{
    anchor1 = Vec2f(0,0);
    anchor2 = Vec2f(0,0);
    control1 = Vec2f(0,0);
    control2 = Vec2f(0,0);
}


void CubicCurve::setVelocities(float v1,float v2)
{
    vFront = v1;
    vEnd = v2;
    
}

void CubicCurve::draw(bool drawControlPoints, float lineWidth,bool isBegin, bool isEnd)
{
        
    drawCurve(vFront ,vEnd,isBegin,isEnd);
    
    if(drawControlPoints)
    {
        gl::lineWidth(1.0f);
        gl::color(Color(1.0f,1.0f,1.0f));
        gl::drawLine(anchor1,control1);
        gl::color(Color(1.0f,0.0f,0.0f));
        gl::drawLine(anchor2,control2);
    }
}

void CubicCurve::drawCap(Vec2f a0, Vec2f a1, Vec2f a2, Vec2f a3, float angleStart)
{
    float capCircumference = (2.0 * M_PI * (a1 - a0).length()/2.0) / 2.0f;
    int numCapSegments = capCircumference / CAP_SEGMENT_WIDTH;
    float angleSep = M_PI / (float)numCapSegments;
    
    
    Vec2f m = (a1 - a0)/2.0f + a0;
    float mLength = (a2 - a1).length();
    
    Vec2f diff = a1-a0;
    
    float angleOff = atan2f(diff.y, diff.x) + M_PI + angleStart;
    
    gl::begin(GL_POLYGON);
    for(int i = 0; i < numCapSegments+1; i++)
    {
        float angle = (float)i *angleSep + angleOff;
        gl::vertex(m.x + mLength * cos(angle),m.y + mLength * sin(angle));
    }
    gl::end();
    
    gl::color(Color(1.0f,1.0f,1.0f));
    gl::drawSolidCircle(a0,2.0f);
    gl::drawSolidCircle(a1,2.0f);
    gl::drawSolidCircle(a2,2.0f);
    gl::drawSolidCircle(a3,2.0f);
    gl::color(Color(1.0f,0.0f,0.0f));
}

void CubicCurve::drawCurve(float lineWidthFront, float lineWidthBack, bool isBegin, bool isEnd)
{
    ci::app::console() << "line widths: " << lineWidthFront << " " << lineWidthBack  << " length of line " << (anchor2 - anchor1).length()<< std::endl;
    Vec2f d1 = control1 - anchor1;
    Vec2f d2 = control2 - anchor2;
    
    Vec2f normalVec1 = Vec2f(-d1.y,d1.x);
    Vec2f normalVec2 = Vec2f(-d2.y,d2.x);
    
    normalVec1.normalize();
    normalVec2.normalize();
    if(normalVec2.x != normalVec2.x || normalVec1.x != normalVec1.x)
    {
        Vec2f d = anchor1 - anchor2;
        normalVec2 = Vec2f(-d.y,d.x);
        normalVec2.normalize();
        
        d = anchor2 - anchor1;
        normalVec1 = Vec2f(-d.y,d.x);
        normalVec1.normalize();
    }
   
    normalVec1 = normalVec1 * Vec2f(lineWidthFront,lineWidthFront);
    normalVec2 = normalVec2 * Vec2f(lineWidthFront,lineWidthFront);
    
    
    drawCubicFromCentreCurve(lineWidthFront,lineWidthBack);
   
    
    
    Vec2f a0 = anchor1 + normalVec1;
    Vec2f a1 = anchor1 - normalVec1;
    Vec2f a2 = (anchor1 - normalVec1) - (anchor2-anchor1).normalized() * lineWidthFront;
    Vec2f a3 = (anchor1 + normalVec1) - (anchor2-anchor1).normalized() * lineWidthFront;
    
    if(isBegin)
    {
        
    
        drawCap(a0,a1,a2,a3,0);
    }
    
    
    if(isEnd)
    {
        Vec2f a0 = anchor2 + normalVec1;
        Vec2f a1 = anchor2 - normalVec1;
        Vec2f a2 = (anchor2 - normalVec1) - (anchor1-anchor2).normalized() * lineWidthBack;
        Vec2f a3 = (anchor2 + normalVec1) - (anchor1-anchor2).normalized() * lineWidthBack;
        
        
        drawCap(a0,a1,a2, a3,M_PI);
    }
}

void CubicCurve::drawCubicFromCentreCurve(float lineWidthFront, float lineWidthBack)
{
    float inc = 0.01f;
    gl::begin(GL_QUAD_STRIP);
    for(float t = 0.0; t <= 1.0f; t+= inc)
    {
        float lineScale = t * (lineWidthBack- lineWidthFront) + lineWidthFront;
        Vec2f p1 = cubicCalc(anchor1,control1,control2,anchor2,t);
        Vec2f p2 = cubicCalc(anchor1,control1,control2,anchor2,t + inc);
        
        Vec2f diff = p2-p1;
        Vec2f normal = Vec2f(-diff.y, diff.x);
        normal.normalize();
        
        gl::vertex(p1 + normal * lineScale);
        gl::vertex(p1 - normal * lineScale);
    }
    gl::end();
}


void CubicCurve::drawCinder(float lineWidth)
{
    Path2d	path;
    gl::lineWidth(lineWidth);
    path.moveTo(anchor1);
    path.curveTo(control1, control2, anchor2);
    
    gl::draw(path);
    
}

Vec2f CubicCurve::cubicCalc(Vec2f p0, Vec2f p1, Vec2f p2, Vec2f p3,float t)
{
    
    float t1 = 1 - t;
    return p0*(t1*t1*t1) + p1*(3*t*t1*t1) + p2*(3*t*t*t1) + p3*(t*t*t);
   
}
