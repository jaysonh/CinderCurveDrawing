#include "CurveDrawer.h"

CurveDrawer::CurveDrawer()
{
    // This is the maximum line width
    lineWidth                   = 4.0f;
    sharpAngleThresh            = 0.0f;
    useKalmanFilter             = true;
    drawPointsPreKalman         = false;
    drawPointsPostKalman        = false;
    drawPointsAngleFilterKalman = false;
    showAngleFilteredLinePoints = false;
    drawQuadratics              = false;
    drawCubics                  = true;
    drawQuadraticPoints         = false;
    drawCubicControlPoints      = false;
    useCubicNormalAdjustment    = true;
}

void CurveDrawer::updateParams(float kalmanSmoothness_,float kalmanRapidness_,float angleThresh_, float cubicNormalMultiplier_, float minDistance_, float sharpAngleThresh_)
{
    sharpAngleThresh        = sharpAngleThresh_;
    minDistance             = minDistance_;
    smoothness              = kalmanSmoothness_;
    rapidness               = kalmanRapidness_;
    cubicNormalMultiplier   = cubicNormalMultiplier_;
}

void CurveDrawer::mouseDown(Vec2f pos,float kalmanSmoothness_,float kalmanRapidness_,float angleThresh_, float cubicNormalMultiplier_, float minDistance_,float sharpAngleThresh_)
{
    sharpAngleThresh        = sharpAngleThresh_;
    minDistance             = minDistance_;
	smoothness              = kalmanSmoothness_;
	rapidness               = kalmanRapidness_;
    cubicNormalMultiplier   = cubicNormalMultiplier_;
	kalmanFilter = KalmanFilter();
	kalmanFilter.init(pos, smoothness, rapidness);

    cubicCurveLines.clear();
    quadCurveLines.clear();
    pointsPreKalman.clear();
    pointsPostKalman.clear();
    
    Vec2f adjustedPos = pos;// - Vec2f(ci::app::getWindowWidth()/2.0, ci::app::getWindowHeight()/2.0f);
    float vel = 0.0f;
    if(pointsPreKalman.size() > 0)
    {
        vel = (1.0f/(pointsPreKalman.back().p - pos).length()) * LINE_SIZE_MULTIPLIER;
        
        
        if(vel > MAX_LINE_WIDTH) vel = MAX_LINE_WIDTH;
        if(vel < MIN_LINE_WIDTH) vel = MIN_LINE_WIDTH;
    }
    
    // Need to makes sure first and second points are atleast lineWidth distance away from each other
    
    pointsPreKalman.push_back(TouchVec2f(adjustedPos));
    pointsPostKalman.push_back(TouchVec2f(adjustedPos));
    
}

void CurveDrawer::mouseUp(MouseEvent event)
{
    
}

void CurveDrawer::toggleUseCubicNormalAdjuster()
{
    useCubicNormalAdjustment = !useCubicNormalAdjustment;
}
void CurveDrawer::toggleDrawCubics()
{
    drawCubics = !drawCubics;
}
void CurveDrawer::toggleShowAnglePoints()
{
    showAngleFilteredLinePoints = !showAngleFilteredLinePoints;
}

void CurveDrawer::toggleKalmanFilter()
{
    useKalmanFilter =  !useKalmanFilter;
}

void CurveDrawer::toggleDrawQuadraticPoints()
{
    drawQuadraticPoints = !drawQuadraticPoints;
}

void CurveDrawer::toggleDrawQuadratics()
{
    drawQuadratics = !drawQuadratics;
}

void CurveDrawer::toggleDrawPointsPreKalman()
{
    
    drawPointsPreKalman = !drawPointsPreKalman;
}
void CurveDrawer::toggleDrawPointsPostKalman()
{
    drawPointsPostKalman =  !drawPointsPostKalman;
}
void CurveDrawer::toggleDrawPointsAngleFilter()
{
    drawPointsAngleFilterKalman =  !drawPointsAngleFilterKalman;
}

void CurveDrawer::loadKalmanPoints()
{
    if(pointsPreKalman.size() > 0)
    {
        pointsPostKalman.clear();
        kalmanFilter.init(pointsPreKalman[0].p,smoothness,rapidness);
        
        for (std::deque<TouchVec2f>::const_iterator itPos = pointsPreKalman.begin(); itPos != pointsPreKalman.end() ; ++itPos)
        {
            kalmanFilter.update((*itPos).p);
            
            if(useKalmanFilter)
            {
                Vec2f kalmanEstimatedPos = kalmanFilter.getEstimation();
                pointsPostKalman.push_back(TouchVec2f(kalmanEstimatedPos, (*itPos).v));
            }else
                pointsPostKalman.push_back(*itPos);
        }
    }
    
    std::deque<QuadraticCurve>  tmpQuadList;
    
    // If we have more than 3 points then calculate quadratic curves using midpoint techique
    if(pointsPostKalman.size() >= 2)
    {
        
        quadCurveLines.clear();
        
        QuadraticCurve curveBegin(pointsPostKalman[0].p,pointsPostKalman[1].p,pointsPostKalman[2].p,pointsPostKalman[2].v,pointsPostKalman[2].v);
        curveBegin.calcBeginningSectionFromPoints();
        quadCurveLines.push_back(curveBegin);
        tmpQuadList.push_back(curveBegin);
        
        for(int i = 2; i < pointsPostKalman.size(); i++)
        {
            Vec2f p0 = pointsPostKalman[i-2].p;
            Vec2f p1 = pointsPostKalman[i-1].p;
            Vec2f p2 = pointsPostKalman[i-0].p;
            
            float vFront = pointsPostKalman[i-1].v;
            float vEnd   = pointsPostKalman[i].v;
            
            if(i == 2)
                vFront = vEnd;
            if(i == pointsPostKalman.size()-1)
                vEnd = vFront;
            
            QuadraticCurve qc(p0,p1,p2,vFront, vEnd);
            qc.calcMidSectionFromPoints();
            
            quadCurveLines.push_back(qc);
            tmpQuadList.push_back(qc);
            
            if(i == pointsPostKalman.size()-1)
            {
                
                QuadraticCurve curveEnd(p0,p1,p2,vFront,vEnd);
                curveEnd.calcEndSectionFromPoints();
                quadCurveLines.push_back(curveEnd);
                tmpQuadList.push_back(curveEnd);
            }
        }
    }
    
    // If we have more than 3 points then calculate cubic curves from quadratics
    cubicCurveLines.clear();
    while(tmpQuadList.size())
    {
        CubicCurve	curve;
        
        curve.anchor1 = tmpQuadList.front().p1;
        curve.anchor2 = tmpQuadList.front().p3;
        
        
        if(cubicCurveLines.size()==0)
        {
            Vec2f controlCurve1 = (tmpQuadList.front().p2 - curve.anchor1) * Vec2f(cubicNormalMultiplier,cubicNormalMultiplier);
            Vec2f controlCurve2 = (tmpQuadList.front().p2 - curve.anchor2) * Vec2f(cubicNormalMultiplier,cubicNormalMultiplier);
            
            curve.control1 = curve.anchor1 + controlCurve1;
            curve.control2 = curve.anchor2 + controlCurve2;
        }else {
            
            if(useCubicNormalAdjustment)
            {
                curve.control2   = tmpQuadList.front().p3 - (tmpQuadList.front().p3 - tmpQuadList.front().p2) * Vec2f(cubicNormalMultiplier,cubicNormalMultiplier);
                
                float magnitude = (curve.anchor2 - curve.control2).length() ;
                
                Vec2f controlLinePrev = cubicCurveLines.back().anchor2 - cubicCurveLines.back().control2;
                
                curve.control1 = curve.anchor1 + controlLinePrev;
                
                
            }else
            {
                curve.control1 = tmpQuadList.front().p2;
                curve.control2 = tmpQuadList.front().p2;
            }
        }
        curve.setVelocities(tmpQuadList.front().vFront, tmpQuadList.front().vEnd);
        cubicCurveLines.push_back(curve);
        
        tmpQuadList.pop_front();
    }
}

void CurveDrawer::mouseDrag(Vec2f pos, float minDistance)
{
    TouchVec2f lastPos = pointsPreKalman.back().p;
    
    float vel = (1.0f / (lastPos.p - pos).length()) * LINE_SIZE_MULTIPLIER;
    
    if(vel > MAX_LINE_WIDTH) vel = MAX_LINE_WIDTH;
    if(vel < MIN_LINE_WIDTH) vel = MIN_LINE_WIDTH;
    
    // If distance is less than 1 replace previous point with new point
    /*if((pos - pointsPreKalman.back().p).length() < 1.0f)
        pointsPreKalman[pointsPreKalman.size()-1] = TouchVec2f(pos,vel);
    else
        pointsPreKalman.push_back(TouchVec2f(pos,vel));*/
    
    if((pos - pointsPreKalman.back().p).length() > 1.0f)
        pointsPreKalman.push_back(TouchVec2f(pos,vel));
    
}

void CurveDrawer::update()
{

}

void CurveDrawer::clear()
{
    cubicCurveLines.clear();
    quadCurveLines.clear();
    pointsPreKalman.clear();
    pointsPostKalman.clear();
}



void CurveDrawer::draw()
{
    //gl::translate(Vec2f(ci::app::getWindowWidth()/2.0, ci::app::getWindowHeight()/2.0f));
    loadKalmanPoints();
    gl::enableAlphaBlending();

    if(drawPointsPreKalman)
    {
        gl::lineWidth(1.0f);
        gl::color(ColorA(1.0, 0.0, 1.0, 1.0));
        gl::begin(GL_LINE_STRIP);
        for (std::deque<TouchVec2f>::const_iterator it = pointsPreKalman.begin(); it != pointsPreKalman.end(); ++it)
        {
            gl::vertex(it->p.x, it->p.y);
        }
        gl::end();
        for (std::deque<TouchVec2f>::const_iterator it = pointsPreKalman.begin(); it != pointsPreKalman.end(); ++it)
        {
            gl::drawSolidCircle((*it).p, 4.0);
        }
        
    }
    if(drawPointsPostKalman)
    {
        gl::lineWidth(1.0f);
        gl::color(ColorA(0, 1, 1, 1.0f));
        gl::begin(GL_LINE_STRIP);
        for (std::deque<TouchVec2f>::const_iterator it = pointsPostKalman.begin(); it != pointsPostKalman.end(); ++it)
        {
            gl::vertex(it->p.x, it->p.y);
        }
        gl::end();
        
        for (std::deque<TouchVec2f>::const_iterator it = pointsPostKalman.begin(); it != pointsPostKalman.end(); ++it)
        {
            gl::drawSolidCircle((*it).p,4.0f);
        }
    }
    
    if(drawQuadratics)
    {
        gl::lineWidth(1.0f);
        gl::color(ColorA(1, 1, 0, 1.0f));
        
        for (std::vector<QuadraticCurve>::iterator it = quadCurveLines.begin(); it != quadCurveLines.end(); ++it)
        {
            (*it).draw();
        }
        
        if(drawQuadraticPoints)
        {
            for (std::vector<QuadraticCurve>::iterator it = quadCurveLines.begin(); it != quadCurveLines.end(); ++it)
            {
                gl::color(ColorA(0, 1, 1, 1.0f));
                gl::drawSolidCircle((*it).p1,3.0f);
                gl::drawSolidCircle((*it).p3,3.0f);
                
                gl::color(ColorA(0, 1, 0, 1.0f));
                gl::drawSolidCircle((*it).p2,3.0f);
            }
        }
    }
    
    if(drawCubics)
    {
    
        gl::color(ColorA(0, 1, 0, 1.0f));
        for (std::vector<CubicCurve>::iterator it = cubicCurveLines.begin(); it != cubicCurveLines.end(); ++it)
        {
            
            if(it == cubicCurveLines.begin())
                (*it).draw(drawCubicControlPoints,lineWidth,true, false);
            else if(it == cubicCurveLines.end()-1)
                (*it).draw(drawCubicControlPoints,lineWidth,false, true);
            else
                (*it).draw(drawCubicControlPoints,lineWidth,false, false);
        }
        ci::app::console() << std::endl;
    }
}

bool CurveDrawer::isDrawCubicControlPoints()
{
    return drawCubicControlPoints;
}

void CurveDrawer::toggleDrawCubicControlPoints()
{
    drawCubicControlPoints = !drawCubicControlPoints;
}

bool CurveDrawer::isUsingKalmanFilter()
{
    return useKalmanFilter;
}

bool CurveDrawer::isDrawPointsPreKalman()
{
    return drawPointsPreKalman;
}

bool CurveDrawer::isDrawQuadratics()
{
    return drawQuadratics;
}
bool CurveDrawer::isDrawQuadraticPoints()
{
    return drawQuadraticPoints;
}

bool CurveDrawer::isDrawCubics()
{
    return drawCubics;
}
bool CurveDrawer::isDrawPointsPostKalman()
{
    return drawPointsPostKalman;
}

bool CurveDrawer::isDrawPointsWithAngleFiltering()
{
    return drawPointsAngleFilterKalman;
}

bool CurveDrawer::isShowAngleFilterPoints()
{
    return showAngleFilteredLinePoints;
}

bool CurveDrawer::isUsingCubicNormalAdjuster()
{
    return useCubicNormalAdjustment;
}

int CurveDrawer::getNumPreKalmanPoints()
{
    return pointsPreKalman.size();
}

int CurveDrawer::getNumPostKalmanPoints()
{
    return pointsPostKalman.size();
    
}


int CurveDrawer::getNumCubics()
{
    return cubicCurveLines.size();
}
int CurveDrawer::getNumQuadratics()
{
    
    return quadCurveLines.size();
}
