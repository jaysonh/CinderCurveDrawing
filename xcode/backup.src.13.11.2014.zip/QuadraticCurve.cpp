//
//  QuadraticCurve.cpp
//  DrawingToolkit
//
//  Created by Engage on 29/10/2014.
//
//

#include "QuadraticCurve.h"

QuadraticCurve::QuadraticCurve(Vec2f p1_, Vec2f p2_, Vec2f p3_, float v1, float v2)
{
    p1 = p1_;
    p2 = p2_;
    p3 = p3_;
    
    vFront = v1;
    vEnd   = v2;
}

void QuadraticCurve::calcMidSectionFromPoints()
{
    Vec2f m1 = getMidPoint(p1,p2);
    Vec2f m2 = getMidPoint(p2,p3);
    
    p1 = m1;
    p2 = p2;
    p3 = m2;
}

void QuadraticCurve::calcBeginningSectionFromPoints()
{
    Vec2f m1 = getMidPoint(p1,p2);
    Vec2f m2 = getMidPoint(p2,p3);
    
    p1 = p1;
    p2 = m1;
    p3 = m1;
}

void QuadraticCurve::calcEndSectionFromPoints()
{
    Vec2f m1 = getMidPoint(p1,p2);
    Vec2f m2 = getMidPoint(p2,p3);
    
    p1 = m2;
    p2 = m2;
    p3 = p3;
}

Vec2f QuadraticCurve::getMidPoint(Vec2f pA, Vec2f pB)
{
    return Vec2f((pB.x - pA.x) / 2.0 + pA.x, (pB.y - pA.y) / 2.0 + pA.y);

}

void QuadraticCurve::draw()
{
    Path2d	path;
    
    path.moveTo(p1);
    
    path.quadTo(p2, p3);
    
    gl::draw(path);
    
    /*gl::drawSolidCircle(p1, 2.0f);
    gl::drawSolidCircle(p2, 4.0f);
    gl::drawSolidCircle(p3, 2.0f);*/
}