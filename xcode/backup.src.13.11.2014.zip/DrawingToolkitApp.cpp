#include "vector"
#include "deque"
#include "cinder/ip/Resize.h"
#include "cinder/app/AppNative.h"
#include "cinder/Rand.h"
#include "cinder/Utilities.h"
#include "cinder/gl/Texture.h"
#include "cinder/Text.h"
#include "cinder/Utilities.h"
#include "cinder/ImageIo.h"
#include "cinder/Font.h"
#include "cinder/Vector.h"
#include "cinder/Path2d.h"
#include "cinder/gl/gl.h"
#include "CinderOpenCV.h"
#include "cinder/gl/Fbo.h"
#include "cinder/Font.h"
#include "CurveDrawer.h"
#include "KalmanFilter.h"
#include "cinder/params/Params.h"
#include "boost/date_time/posix_time/posix_time.hpp"

#define MIN_DISTANCE    0.0f

#define CUBIC_FILTER 0.275f
using namespace ci;
using namespace ci::app;
using namespace std;

enum CURVE_MODE { QUADRATIC, CUBIC, ANGLE, QUADANGLE };

class DrawingToolkitApp : public AppNative
{

public:
	DrawingToolkitApp();
	void setup();
	void mouseDown(MouseEvent event);
	void mouseUp(MouseEvent event);
	void mouseDrag(MouseEvent event);
	void keyDown(KeyEvent event);

	void update();
	void draw();


private:
    params::InterfaceGlRef          mParams;
    float                           sharpAngleThresh;
    float                           kalmanSmoothness;
    float                           kalmanRapidness;
    float                           angleThresh;
    float                           cubicNormalMultiplier;
    float                           minDistance;
	Font							font;
    
	CURVE_MODE curveMode;
	
	CurveDrawer					curveDrawer;
	
bool							saveFBO;
	gl::Fbo							fbo;
    
    void drawInfoPanel();
    void toggleCubicNormalAdjust();
    void toggleKalmanFilter();
    void toggleDrawPointsPreKalman();
    void toggleDrawPointsPostKalman();
    void toggleDrawPointsAngleFilter();
    void toggleShowAngleFilterPoints();
    void toggleDrawQuadratics();
    void toggleDrawQuadraticPoints();
    void toggleDrawCubics();
    void toggleDrawCubicControlPonts();
    void saveScreenshot();
};

DrawingToolkitApp::DrawingToolkitApp()
{

}

void DrawingToolkitApp::saveScreenshot()
{
    saveFBO = true;
}

void DrawingToolkitApp::setup()
{
	gl::enableAlphaBlending(); 

	saveFBO = false;
	curveMode = ANGLE;

    // Default values
    kalmanSmoothness        = 0.0001f;
    kalmanRapidness         = 0.001f;
    angleThresh             = 0.0f;
    cubicNormalMultiplier   = 0.75;
    minDistance             = 0.0;
    sharpAngleThresh        = 1.0f;
    font = Font("Arial", 12.0f);
    mParams = params::InterfaceGl::create( getWindow(), "parameters", toPixels( Vec2i( 340, 300 ) ) );
    mParams->addParam( "Kalman Smoothness", &kalmanSmoothness ).min( 0.00000f ).max( 2.5f ).precision( 5 ).step( 0.0001f );
    mParams->addParam( "Kalman Rapidness", &kalmanRapidness ).min( 0.00000f ).max( 2.5f ).precision( 4 ).step( 0.01f );
    mParams->addParam( "Angle Thresh", &angleThresh ).min( 0.00000f ).max( 1.0 ).precision( 2 ).step( 0.01f );
    mParams->addButton("Toggle KalmanFilter", std::bind( &DrawingToolkitApp::toggleKalmanFilter, this ) );
    mParams->addButton("Draw Points Pre Kalman", std::bind( &DrawingToolkitApp::toggleDrawPointsPreKalman, this ) );
    mParams->addButton("Draw Points Post Kalman", std::bind( &DrawingToolkitApp::toggleDrawPointsPostKalman, this ) );
    mParams->addButton("Draw Points With Angle Filtering", std::bind( &DrawingToolkitApp::toggleDrawPointsAngleFilter, this ) );
    mParams->addButton("Show Angle Filter Points", std::bind( &DrawingToolkitApp::toggleShowAngleFilterPoints, this ) );
    mParams->addButton("Draw Quadratics", std::bind( &DrawingToolkitApp::toggleDrawQuadratics, this ) );
    mParams->addButton("Draw Quadratic Points", std::bind( &DrawingToolkitApp::toggleDrawQuadraticPoints, this ) );
    mParams->addButton("Draw Cubics", std::bind( &DrawingToolkitApp::toggleDrawCubics, this ) );
    mParams->addButton("Save Screenshot", std::bind( &DrawingToolkitApp::saveScreenshot, this ) );
    mParams->addParam( "Cubic Normal Multiplier", &cubicNormalMultiplier ).min( 0.00000f ).max( 5.0 ).precision( 2 ).step( 0.01f );
    mParams->addButton("Use Cubic Normal Adjust", std::bind( &DrawingToolkitApp::toggleCubicNormalAdjust, this ) );
    mParams->addButton("Draw Cubic Control Points", std::bind( &DrawingToolkitApp::toggleDrawCubicControlPonts, this ) );
    mParams->addParam( "SharpAngle test", &sharpAngleThresh ).min( 0.00f ).max( 3.15f ).precision( 2).step( 0.01f );
    mParams->addParam( "Distance thresh", &minDistance ).min( 0.00f ).max( 50.5f ).precision( 2).step( 0.1f );
    
    

}

void DrawingToolkitApp::toggleDrawCubicControlPonts()
{
    curveDrawer.toggleDrawCubicControlPoints();
}
void DrawingToolkitApp::toggleCubicNormalAdjust()
{
    curveDrawer.toggleUseCubicNormalAdjuster();
}

void DrawingToolkitApp::toggleDrawQuadraticPoints()
{
    curveDrawer.toggleDrawQuadraticPoints();
}

void DrawingToolkitApp::toggleDrawCubics()
{
    curveDrawer.toggleDrawCubics();
}

void DrawingToolkitApp::toggleDrawQuadratics()
{
    curveDrawer.toggleDrawQuadratics();
}

void DrawingToolkitApp::toggleShowAngleFilterPoints()
{
    curveDrawer.toggleShowAnglePoints();
}

void DrawingToolkitApp::toggleDrawPointsPreKalman()
{
    curveDrawer.toggleDrawPointsPreKalman();
}

void DrawingToolkitApp::toggleDrawPointsPostKalman()
{
    
    curveDrawer.toggleDrawPointsPostKalman();
}
void DrawingToolkitApp::toggleDrawPointsAngleFilter()
{
    curveDrawer.toggleDrawPointsAngleFilter();
    
}
void DrawingToolkitApp::toggleKalmanFilter()
{
    curveDrawer.toggleKalmanFilter();
}
void DrawingToolkitApp::mouseDown(MouseEvent event)
{
	curveDrawer.mouseDown(event.getPos(),kalmanSmoothness,kalmanRapidness,angleThresh,cubicNormalMultiplier,minDistance,sharpAngleThresh);
}

void DrawingToolkitApp::mouseUp(MouseEvent event)
{
    curveDrawer.mouseUp(event);
}

void DrawingToolkitApp::mouseDrag(MouseEvent event)
{
    
	curveDrawer.mouseDrag(event.getPos(), MIN_DISTANCE);
}

void DrawingToolkitApp::keyDown(KeyEvent event)
{
	if (event.getChar() == ' ')
	{
		curveDrawer.clear();
	}
	 if (event.getChar() == 's' || event.getChar() == 'S')
	{
		saveFBO = true;
	}
    
    if(event.getChar() == '1')
    {
        
        curveDrawer.mouseDown( Vec2f(300,100),kalmanSmoothness,kalmanRapidness,angleThresh,cubicNormalMultiplier,minDistance,sharpAngleThresh);
        curveDrawer.mouseDrag( Vec2f(300,800),MIN_DISTANCE);
        curveDrawer.mouseDrag( Vec2f(200,100),MIN_DISTANCE);
    }

}

void DrawingToolkitApp::update()
{
	
	
        curveDrawer.updateParams(kalmanSmoothness,kalmanRapidness,angleThresh,cubicNormalMultiplier,minDistance,sharpAngleThresh);
		curveDrawer.update();
		

}

void DrawingToolkitApp::draw()
{

	gl::clear(Color(0, 0, 0));
    
    
			curveDrawer.draw();
    
    drawInfoPanel();

    mParams->draw();
	if (saveFBO)
	{
		saveFBO = false;
		writeImage("screnshot" + toString(boost::posix_time::second_clock::universal_time()) + ".png", copyWindowSurface());
	}
    
}

void DrawingToolkitApp::drawInfoPanel()
{
    gl::pushMatrices();
    
    gl::translate(Vec2f(350,00));
    gl::color(Color(1, 1, 1));
    gl::drawString("Framerate: " + toString(getAverageFps()), Vec2f(10, 20.0f), Color::white(), font);
    gl::drawString("Num Pre Kalman Points:       " + toString(curveDrawer.getNumPreKalmanPoints()), Vec2f(10, 35.5f), Color::white(), font);
    gl::drawString("Num Post Kalman Points:       " + toString(curveDrawer.getNumPostKalmanPoints()), Vec2f(10, 50.5f), Color::white(), font);
  
    gl::drawString("Num Quadratics:             " + toString(curveDrawer.getNumQuadratics()), Vec2f(10, 80.5f), Color::white(), font);
    gl::drawString("Num Cubics:             " +    toString(curveDrawer.getNumCubics()), Vec2f(10, 90.5f), Color::white(), font);
    //gl::drawString("Using Kalman Filter:       " + toString(curveTester.isUsingKalmanFilter()), Vec2f(10, 87.5f), Color::white(), font);
    gl::drawString("Draw Points Pre Kalman:    " + toString(curveDrawer.isDrawPointsPreKalman()), Vec2f(10, 102.5f), Color(1, 0, 1), font);
    
    gl::drawString("Draw Points Post Kalman:   " + toString(curveDrawer.isDrawPointsPostKalman()), Vec2f(10, 117.5f), Color(0, 1, 1), font);
    gl::drawString("Draw Points With Ang Filt: " + toString(curveDrawer.isDrawPointsWithAngleFiltering()), Vec2f(10, 132.5f), Color(1, 1, 1), font);
    gl::drawString("Show Angle Filter Points:  " + toString(curveDrawer.isShowAngleFilterPoints()), Vec2f(10, 147.5f), Color::white(), font);
    gl::drawString("Draw Quadratics:           " + toString(curveDrawer.isDrawQuadratics()), Vec2f(10, 162.5f), Color(1, 1, 0), font);
    gl::drawString("Draw Quadratic Points:     " + toString(curveDrawer.isDrawQuadraticPoints()), Vec2f(10, 177.5f), Color(0, 1, 1), font);
    gl::drawString("Draw Cubics:               " + toString(curveDrawer.isDrawCubics()), Vec2f(10, 192.5f), Color(0, 1, 0), font);
    gl::drawString("Use Cubic Normal Adjus:    " + toString(curveDrawer.isUsingCubicNormalAdjuster()), Vec2f(10, 207.5f), Color(0, 1, 0), font);
    
    
    
    gl::popMatrices();
}


CINDER_APP_NATIVE(DrawingToolkitApp, RendererGl)
